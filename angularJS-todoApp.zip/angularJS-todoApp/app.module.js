"use strict";
// getter syntax
angular.module("todoApp", []);